package com.lgcns.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;

class BusItem {
	public String name;
	public String time;
	public int loc; // Location meter;
	public int diff;
	public int speed; // m/s

	public BusItem() {
	};

	public BusItem(String _name, String _time, int _loc, int _diff) {
		name = _name;
		time = _time;
		loc = _loc;
		diff = _diff;
	}

	public String toString() {
		return time + name + "," + loc;
	}
}

class StaItem {
	String name;
	int loc;
	double maxSpeed; // m/s
}


public class BusMan {
	public String curTime = "";
	static BusMan instance_ = null;

	static synchronized public BusMan getInstance() {
		if (instance_ == null)
			instance_ = new BusMan();
		return instance_;
	}

	private BusMan() {

	}

	public Map<String, BusItem> busMap = new TreeMap<>();
	public Map<String, StaItem> staMap = new TreeMap<>();

	public synchronized void AddStationItem(StaItem item) {
		staMap.put(item.name, item);
	}

	public synchronized void AddBusItem(BusItem item) {
		curTime = item.time;
		if (!busMap.containsKey(item.name))
			busMap.put(item.name, item);
		else {
			BusItem base = busMap.get(item.name);
			item.speed = item.loc - base.loc;
			busMap.put(item.name, item);
		}
	}

	public synchronized void AddBusItem(String name, String time) {
		curTime = time;
		BusItem item = busMap.get(name);
		
		int secbus = MyUtil.time2sec(item.time);
		int seccur = MyUtil.time2sec(time);
		
		if(secbus >= seccur)
			return;
		int sec =  seccur - secbus;
		item.time = MyUtil.addSec(item.time, sec);
		item.loc = item.loc + (int)item.speed * sec;
		busMap.put(item.name, item);
	
	}
	
	public synchronized void AddBusItem(String time) {
		curTime = time;
		for(BusItem item: busMap.values())
		{
			int secbus = MyUtil.time2sec(item.time);
			int seccur = MyUtil.time2sec(time);
			
			if(secbus >= seccur)
				continue;
			int sec =  seccur - secbus;
			item.time = MyUtil.addSec(item.time, sec);
			item.loc = item.loc + (int)item.speed * sec;
			busMap.put(item.name, item);
		}
	}
	
	public String getPrePost(String name) {
		BusItem base = busMap.get(name);
		BusItem pre = new BusItem("NOBUS", base.time, base.loc, 99999);
		BusItem pos = new BusItem("NOBUS", base.time, base.loc, 99999);
		for (BusItem item : busMap.values()) {
			if (item.name == base.name)
				continue;
//			System.out.println("item " + item);
//			System.out.println("base " + base);
			if (item.loc - base.loc > 0) {// ��������
//				System.out.println("diff " + Math.abs(base.loc - item.loc));
				if (Math.abs(base.loc - item.loc) < Math.abs(pre.diff)) {
					pre = item;
					pre.diff = Math.abs(base.loc - item.loc);
				}
			} else {// ��������
//				System.out.println("diff2 " + Math.abs(base.loc - item.loc));
				if (Math.abs(item.loc - base.loc) < Math.abs(pos.diff)) {
					pos = item;
					pos.diff = Math.abs(base.loc - item.loc);
				}
			}
		}

		if (pre.name == "NOBUS")
			pre.diff = 0;
		if (pos.name == "NOBUS")
			pos.diff = 0;
		String ans = String.format("%s#%s#%s,%05d#%s,%05d", base.time, base.name, pre.name, pre.diff, pos.name,
				pos.diff);
		System.out.println(ans);
		return ans;
	}



	public void ParseStationFile(String filepath) {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(new File(filepath)));
			String line = null;
			while ((line = br.readLine()) != null) {
				String[] words = line.split("#");
				StaItem item = new StaItem();
				item.name = words[0];
				item.loc = Integer.parseInt(words[1]);
				item.maxSpeed = Integer.parseInt(words[2]) * 1000 / 60 / 60;
				this.AddStationItem(item);
			}
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String[] getPrePostList() {
		ArrayList<String> ans = new ArrayList<>();

		LinkedList<String> keys = new LinkedList<>(busMap.keySet());
		Collections.sort(keys);
		for (String key : keys) {
			ans.add(getPrePost(key));
		}
		return ans.toArray(new String[ans.size()]);
	}
	
	public String[] getArrival(String time) {
		ArrayList<String> ans = new ArrayList<>();

		LinkedList<String> keys = new LinkedList<>(staMap.keySet());
		Collections.sort(keys);
		for (String key : keys) {
			
			int loc = staMap.get(key).loc;
			int minDiff = loc;
			BusItem pre = null;
			for(BusItem bus: busMap.values())
			{
				if(bus.loc < loc)
				{
					if(minDiff > loc - bus.loc)
					{
						minDiff = loc - bus.loc;
						pre = bus;
						pre.diff = minDiff;
					}
				}
			}
			String str = null;
			if(pre != null)
				str = String.format("%s#%s#%s,%05d", time, key, pre.name, pre.diff);
			else
				str = String.format("%s#%s#NOBUS,00000", time, key);
			
			System.out.println(str);
			ans.add(str);
		}
		
		return ans.toArray(new String[ans.size()]);
	}
	
	public int getArrivalSec(String staName, BusItem bus) {
		int loc = bus.loc;
		double sec = 0.;
		double curMaxSpeed = bus.speed;
		for(StaItem sta: staMap.values()) {
			if(sta.loc < loc) {
				if(sta.name.equals(staName)) {
					break;
				}
				curMaxSpeed = sta.maxSpeed;
				continue;
			}
			
			sec += (double)(sta.loc - loc) / Math.min(curMaxSpeed, bus.speed);
			loc = sta.loc;
			curMaxSpeed = sta.maxSpeed;
			
			if(sta.name.equals(staName)) {
				break;
			}
		}
		return (int)sec;
	}
	
	public int getArrivalSec(BusItem bus1, BusItem bus2) {
		BusItem base, target;
		if(bus1.loc < bus2.loc)
		{
			base = bus1;
			target = bus2;
		}
		else {
			base = bus2;
			target = bus1;
		}
			
		int loc = base.loc;
		double sec = 0.;
		double curMaxSpeed = base.speed;
		for(StaItem sta: staMap.values()) {
			if(sta.loc < loc) {
				curMaxSpeed = sta.maxSpeed;
				continue;
			}

			if(sta.loc > target.loc) {
				break;
			}
			
			sec += (double)(sta.loc - loc) / Math.min(curMaxSpeed, base.speed);
			loc = sta.loc;
			curMaxSpeed = sta.maxSpeed;
			
		}
		sec += (double)(target.loc - loc) /  Math.min(curMaxSpeed, base.speed);
		return (int)sec;
	}
	public String getPrePostSec(String _name)
	{
		BusItem base = busMap.get(_name);
		BusItem pre = null;
		BusItem post = null;
		for(BusItem bus: busMap.values()) {
			if(bus.name.equals(_name))
				continue;
			
			int sec = getArrivalSec(bus, base);
			if(bus.loc > base.loc)	//���� ������
			{
				if(pre == null || pre.diff > sec)
				{
					pre = bus;
					pre.diff = sec;
				}					
			}
			else if(bus.loc < base.loc){	//���� ������
				if(post == null || post.diff > sec)
				{
					post = bus;
					post.diff = sec;
				}
			}
			else
				continue;
		}
		
		String strPre = "NOBUS#00:00:00";
		if(pre != null)
			strPre = String.format("%s#%s", pre.name, MyUtil.sec2time(pre.diff));
		
		
		String strPost = "NOBUS#00:00:00";
		if(post != null)
			strPost = String.format("%s#%s", post.name,MyUtil.sec2time(post.diff));
			
		return strPre + "#" + strPost;
		
	}
	
	public String[] getFastArrival(String time) {
		ArrayList<String> ans = new ArrayList<>();

		LinkedList<String> keys = new LinkedList<>(staMap.keySet());
		Collections.sort(keys);
		for (String key : keys) {
			
			int locSta = staMap.get(key).loc;
			int minDiff = 24*60*60;
			BusItem pre = null;
			for(BusItem bus: busMap.values())
			{
				if(bus.loc < locSta)
				{
					if(minDiff > getArrivalSec(key, bus))
					{
						pre = bus;
						pre.diff = getArrivalSec(key, bus);
					}
				}
			}
			String str = null;
			if(pre != null)
				str = String.format("%s#%s#%s,%s", time, key, pre.name, MyUtil.addSec(time, pre.diff));
			else
				str = String.format("%s#%s#NOBUS,00:00:00", time, key);
			
			System.out.println(str);
			ans.add(str);
		}
		
		return ans.toArray(new String[ans.size()]);
	}
	
	public void printBusList()
	{
		for(BusItem item: busMap.values()) {
			System.out.println(String.format("bus %s#%s#%05d,%d", item.time, item.name, item.loc, item.speed));
		}
	}

	public String getGuestArrival(String staName, int curLoc) {
	
		for(BusItem item: busMap.values()) 
		{
			item.diff = getArrivalSec(staName, item);;
			busMap.put(item.name, item);
		}
	
		int minLoc = 99999;
		StaItem nearSta = null;
		for(StaItem item: staMap.values())
		{
			if(minLoc > Math.abs(item.loc - curLoc)) {
				minLoc = Math.abs(item.loc - curLoc);
				nearSta = item;
			}
		}
		
		int minDiff = staMap.get(staName).loc - curLoc;	//�ɾ��
		
		System.out.println(nearSta.name +"," +minDiff+","+minLoc);
		for(BusItem item: busMap.values()) 
		{
			int sec = getArrivalSec(nearSta.name, item);
			if(sec < minLoc)
			{
				//Ż�� ����.
				item.diff = 0;
				busMap.put(item.name, item);
			}
			else
			{
				System.out.println(item.name + ","+ item.diff);
				if(minDiff > item.diff)
					minDiff = item.diff;
			}
		}
		
		return MyUtil.sec2time(MyUtil.time2sec(curTime) + minDiff);
	}
}
