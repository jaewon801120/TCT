package com.lgcns.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class RunManager {

	public static void main(String[] args) throws IOException {

		File inFile = new File("INFILE/LOCATION.TXT");

		BufferedReader br = new BufferedReader(new FileReader(inFile));
		String line = null;
		while ((line = br.readLine()) != null) {
			System.out.println(line);

			if (line.equals("PRINT")) {
				String[] lineData = line.split("#");
				for (String parseData : lineData) {
					System.out.println(parseData);
					Bus bus = new Bus();
					if (parseData.startsWith("BUS")) {
						String[] busData = parseData.split(",");

						String busName = busData[0];
						String busLocation = busData[1];

						bus.name = busName;
						bus.index = Integer.parseInt(busName.substring(3, 5));
						bus.location = Integer.parseInt(busLocation);

						System.out.println(bus);

					}
				}
			}
		}

		PrintWriter pw = new PrintWriter("OUTFILE/PREPOST.TXT");

	}

}

class Bus {
	String name;
	int index;
	int location;
	int time;

	@Override
	public String toString() {
		return "Bus [name=" + name + ", index=" + index + ", location=" + location + ", time=" + time + "]";
	}
}
