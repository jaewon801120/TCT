package com.lgcns.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;

class BusItem {
	public String name;
	public String time;
	public int loc; // Location meter;
	public int diff;
	public int speed;	//m/s

	public BusItem() {
	};

	public BusItem(String _name, String _time, int _loc, int _diff) {
		name = _name;
		time = _time;
		loc = _loc;
		diff = _diff;
	}

	public String toString() {
		return time + name + "," + loc;
	}
}

class BusMan {
	public HashMap<String, BusItem> busMap = new HashMap<>();

	public void Add(BusItem item) {
		if(!busMap.containsKey(item.name))
			busMap.put(item.name, item);
		else
		{
			BusItem base = busMap.get(item.name);
			item.speed = item.loc - base.loc;
			busMap.put(item.name, item);
		}
	}

	public String getPrePost(String name) {
		LinkedList<BusItem> items = new LinkedList(busMap.values());
		BusItem base = busMap.get(name);
		BusItem pre = new BusItem("NOBUS", base.time, base.loc, 99999);
		BusItem pos = new BusItem("NOBUS", base.time, base.loc, 99999);
		for (BusItem item : items) {
			if (item.name == base.name)
				continue;
//			System.out.println("item " + item);
//			System.out.println("base " + base);
			if (item.loc - base.loc > 0) {// ��������
//				System.out.println("diff " + Math.abs(base.loc - item.loc));
				if (Math.abs(base.loc - item.loc) < Math.abs(pre.diff)) {
					pre = item;
					pre.diff = Math.abs(base.loc - item.loc);
				}
			} else {// ��������
//				System.out.println("diff2 " + Math.abs(base.loc - item.loc));
				if (Math.abs(item.loc - base.loc) < Math.abs(pos.diff)) {
					pos = item;
					pos.diff = Math.abs(base.loc - item.loc);
				}
			}
		}

		if (pre.name == "NOBUS")
			pre.diff = 0;
		if (pos.name == "NOBUS")
			pos.diff = 0;
		String ans = String.format("%s#%s#%s,%05d#%s,%05d", base.time, base.name, pre.name, pre.diff, pos.name,
				pos.diff);
		System.out.println(ans);
		return ans;
	}

	public String[] getPrePostList() {
		ArrayList<String> ans = new ArrayList<>();

		LinkedList<String> keys = new LinkedList<>(busMap.keySet());
		Collections.sort(keys);
		for (String key : keys) {
			ans.add(getPrePost(key));
		}
		return ans.toArray(new String[ans.size()]);
	}

	public void printBusList()
	{
		for(BusItem item: busMap.values()) {
			System.out.println(String.format("bus %s#%s#%05d,%d", item.time, item.name, item.loc, item.speed));
		}
	}

}

public class RunManager2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File to = new File("INFILE/LOCATION.TXT");

		BusMan bmgr = new BusMan();

		try {
			BufferedReader br = new BufferedReader(new FileReader(to));
			String line = null;
			while ((line = br.readLine()) != null) {
				// System.out.println(line);
				String[] words = line.split("#");
				String curTime = "";
				for (String word : words) {
					if (word.startsWith("BUS")) {
						if (curTime != "") {
							// ��������
							BusItem item = new BusItem();
							String[] busInfo = word.split(",");
							item.time = curTime;
							item.name = busInfo[0];
							item.loc = Integer.parseInt(busInfo[1]);
							bmgr.Add(item);
						} else {
							System.out.println("error");
						}
					} else {
						if (word.equals("PRINT")) {
							String[] ans = bmgr.getPrePostList();
							PrintWriter pw = new PrintWriter("OUTFILE/PREPOST.TXT");
							for (String ll : ans) {
								pw.println(ll);
							}
							pw.close();
						} else {
							// �ð�����
							curTime = word;
						}

					}
					// System.out.println(word);
				}
			}
			
			bmgr.printBusList();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
