package com.lgcns.test;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerHandler implements Runnable {

	public static void main(String[] args) {
		Thread th = new Thread(new ServerHandler(9876));
		th.start();

		try {
			Thread.sleep(1000 * 60 * 60);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	boolean bRun;
	int port;
	ServerSocket listener;
	
	ServerHandler(int port_) {
		port = port_;
		try {
			listener = new ServerSocket(port);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		try {

			while (!listener.isClosed()) {
				System.out.println("Waiting.. Port:" + port);
				Socket socket = listener.accept();
				System.out.println("Connected:" + socket.getPort());
				Thread th = new Thread(new ClientHandler(socket, new DoSomething()));
				th.start();
			}

			listener.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}