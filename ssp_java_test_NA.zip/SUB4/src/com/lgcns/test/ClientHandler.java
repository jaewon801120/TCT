package com.lgcns.test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;

public class ClientHandler implements Runnable {

	Socket socket;
	String name;
	DoSomething handler;
	ClientHandler(Socket socket_, DoSomething _handler) {
		socket = socket_;
		name = null;
		handler = _handler;
	}

	@Override
	public void run() {
		System.out.println("Client Conneted:" + socket.getPort());
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintWriter out = new PrintWriter(socket.getOutputStream());
			String line = null;
			while ((line = br.readLine()) != null) {
				// Do Something
				;
				System.out.println(line);
				String ret = handler.doSomething(line);
				if(ret != "") {
					out.println(ret);
					out.flush();
				}
					
				System.out.println(ret);
				
			}
		} catch (SocketException e) {
			System.out.println("Socket Exception:" + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Disconnected:" + socket.getPort());
	}

}