package com.lgcns.test;

import java.io.IOException;



public class RunManager {

	public static void main(String[] args) {		
		
		BusMan bmgr = BusMan.getInstance();
		bmgr.ParseStationFile("INFILE/STATION.TXT");
		
		
		try {
			ServerHandler hdr = new ServerHandler(9876);
			Thread th = new Thread(hdr);
			th.start();
			
			System.out.println("Start CLIENT.EXE");
			Process pClient = Runtime.getRuntime().exec("./CLIENT.EXE");
			pClient.waitFor();
			System.out.println("CLIENT.EXE EXIT");
			
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
		
	}
}
