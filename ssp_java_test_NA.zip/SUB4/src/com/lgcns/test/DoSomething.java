package com.lgcns.test;

import java.io.IOException;
import java.io.PrintWriter;

public class DoSomething {
	String name = null;
	public String doSomething(String line) {
		BusMan bmgr = BusMan.getInstance();
		if(name == null)
			name = line;
		else {
			if(name.startsWith("BUS")) {
				if(line.equals("PRINT")) {
					System.out.println(name +":" +line);
					return "NOBUS#00:00:00#BUS02#00:00:00";
				}
				else {
					System.out.println("Add:" + name + line);
					String[] w = line.split("#");
					if(w.length < 2) {
						bmgr.AddBusItem(name, w[0]);
					}
					else {
						BusItem item = new BusItem();
						item.name = name;
						item.time = w[0];
						item.loc = Integer.parseInt(w[1]);
						bmgr.AddBusItem(item);
					}
				}
			}
			else if(name.startsWith("MOBILE")) {
				if(line.equals("PRINT")) {
					bmgr.printBusList();
					System.out.println(name +":" +line);
					MyUtil.fileWrite("OUTFILE/PREPOST.TXT", bmgr.getPrePostList());
					MyUtil.fileWrite("OUTFILE/ARRIVAL.TXT", bmgr.getArrival(bmgr.curTime));
					Process proc;
					try {
						proc = Runtime.getRuntime().exec("./SIGNAGE.EXE");
						PrintWriter out = new PrintWriter(proc.getOutputStream());
						System.out.println(bmgr.curTime);
						String[] arrivals = bmgr.getFastArrival(bmgr.curTime);
						
						for(String l: arrivals) {
							out.println(l);
							System.out.println(l);
						}
							
						out.println("\n");
						out.flush();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				else {//line = STA07#02130	2130m�� �°��� STA07�� �����ϴ� �ð�
					System.out.println(name +":" +line);
					String[] w = line.split("#");
					return bmgr.getGuestArrival(w[0], Integer.parseInt(w[1]));
				}
			}
		}
		return "";
	}
}
