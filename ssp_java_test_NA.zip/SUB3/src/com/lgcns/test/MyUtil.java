package com.lgcns.test;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class MyUtil{
	public static int time2sec(String time)
	{
		String[] t = time.split(":");
		int sec = Integer.parseInt(t[0]) * 60 * 60;
		sec += Integer.parseInt(t[1]) * 60;
		sec += Integer.parseInt(t[2]);
		return sec;
	}
	
	public static String sec2time(int sec)
	{
		int s = sec%60;
		int m = (sec/60)%60;
		int h = sec/60/60;
		
		return String.format("%02d:%02d:%02d",h,m,s);
	}
	
	public static String addSec(String time, int sec)
	{
		int s = time2sec(time);
		return sec2time(s+sec);
	}
	
	public static void fileWrite(String filepath, String[] contensts) {
		PrintWriter pw;
		try {
			pw = new PrintWriter(filepath);
			for (String ll : contensts) {
				pw.println(ll);
			}
			pw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}