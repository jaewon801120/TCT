package com.lgcns.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public class RunManager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, String> m = new HashMap<String, String>();
		String serverCommandFile = "./INFO/SERVER_COMMAND.TXT";
		try {
			readMap(m, serverCommandFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Scanner in = new Scanner(System.in);
		String input = in.nextLine();

		String[] arrDevice = null;
		String[] arr = input.split("#");
		if (arr.length == 0) {
			//System.out.println("End");
			return;
		} else {
			arrDevice = arr[1].split(",");
		}

		String out = "";
		if (arr.length == 2) {

		} else if (arr.length == 3) {
			for (int i = 0; i < arrDevice.length; i++) {
				out += arrDevice[i] + ":" + m.get(arr[0]) + "#" + arr[2];
				if (i != arrDevice.length - 1) {
					out += "\r\n";
				}
			}
		} else {

		}

		System.out.println(out);
//		for (String key : m.keySet()) {
//			System.out.println(key + " : " + m.get(key));
//		}
	}

	public static void readMap(HashMap<String, String> m, String filePath) throws IOException {

		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		try {
			fileReader = new FileReader(filePath);
			bufferedReader = new BufferedReader(fileReader);
			String line;
			int nLine = 0;
			while ((line = bufferedReader.readLine()) != null) {
				nLine++;
				//System.out.println("line " + nLine + " : " + line);
				String[] arr = line.split("#");
				m.put(arr[0], arr[1]);
				//System.out.println("key : " + arr[0] + ", value : " + arr[1]);
			}

		} finally {
			if (bufferedReader != null)
				try {
					bufferedReader.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
			if (fileReader != null)
				try {
					fileReader.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
		}
	}
}
