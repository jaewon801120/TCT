package com.lgcns.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public class RunManager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, String> m = new HashMap<String, String>();
		String serverCommandFile = "./INFO/SERVER_COMMAND.TXT";
		try {
			readMap(m, serverCommandFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Scanner in = new Scanner(System.in);
		String input = in.nextLine();

		String[] arrDevice = null;
		String[] arr = input.split("#");
		if (arr.length == 0) {
			// System.out.println("End");
			return;
		} else {
			arrDevice = arr[1].split(",");
		}

		String out = "";
		if (arr.length == 2) {

		} else if (arr.length == 3) {
			for (int i = 0; i < arrDevice.length; i++) {
				out += m.get(arr[0]) + "#" + arr[2];

				String path = "./DEVICE/REQ_TO_" + arrDevice[i] + ".TXT";
				try {
					writeDeviceReq(path, out);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} else {

		}
		

		try {
			Thread.sleep(500 * arrDevice.length);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		out = "";
		for (int i = 0; i < arrDevice.length; i++) {
			String resPath = "./DEVICE/RES_FROM_" + arrDevice[i] + ".TXT";
			try {
				out += readAll(resPath);
				if (i != arrDevice.length - 1) {
					out += ",";
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println(out);
	}

	public static void readMap(HashMap<String, String> m, String filePath) throws IOException {

		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		try {
			fileReader = new FileReader(filePath);
			bufferedReader = new BufferedReader(fileReader);
			String line;
			int nLine = 0;
			while ((line = bufferedReader.readLine()) != null) {
				nLine++;
				// System.out.println("line " + nLine + " : " + line);
				String[] arr = line.split("#");
				m.put(arr[0], arr[1]);
				// System.out.println("key : " + arr[0] + ", value : " + arr[1]);
			}

		} finally {
			if (bufferedReader != null)
				try {
					bufferedReader.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
			if (fileReader != null)
				try {
					fileReader.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
		}
	}

	public static void writeDeviceReq(String filePath, String content) throws IOException {

		FileWriter fileWriter = null;
		BufferedWriter bufferedWriter = null;
		try {
			fileWriter = new FileWriter(filePath);
			bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.write(content);

		} finally {
			if (bufferedWriter != null)
				try {
					bufferedWriter.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
			if (fileWriter != null)
				try {
					fileWriter.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
		}
	}

	public static String readAll(String filePath) throws IOException {

		StringBuilder stringBuilder;
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		try {
			stringBuilder = new StringBuilder();
			fileReader = new FileReader(filePath);
			bufferedReader = new BufferedReader(fileReader);
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuilder.append(line);
				break;
			}

		} finally {
			if (bufferedReader != null)
				try {
					bufferedReader.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
			if (fileReader != null)
				try {
					fileReader.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
		}

		return stringBuilder.toString();
	}
}
