package com.lgcns.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class RunManager {

	public static HashMap<String, JsonObject> mapDeviceInfo = new HashMap<String, JsonObject>();
	public static HashMap<String, HashMap<String, String[]>> mapServerCommandInfo = new HashMap<String, HashMap<String, String[]>>();

	public static void main(String[] args) {

		String deviceInfoFile = "./INFO/DEVICE.JSON";
		try {
			String deviceInfo = readAll(deviceInfoFile);
			JsonObject jsonObj = (JsonObject) JsonParser.parseString(deviceInfo);
			JsonElement je = jsonObj.get("deviceInfo");
			JsonArray jaInfo = je.getAsJsonArray();
			int infoCount = jaInfo.size();
			for (int j=0; j<infoCount; j++) {
				JsonElement jeInfo = jaInfo.get(j);
				JsonObject joDevice = jeInfo.getAsJsonObject();
				String type = joDevice.get("type").getAsString();
				int paraCount = joDevice.get("parallelProcessingCount").getAsInt();
				JsonArray ja = joDevice.get("deviceList").getAsJsonArray();
				int len = ja.size();
				for (int i = 0; i < len; i++) {
					JsonElement jae = ja.get(i);
					JsonObject jao = jae.getAsJsonObject();
					JsonElement device = jao.get("device");
					jao.addProperty("type", type);
					jao.addProperty("parallelProcessingCount", paraCount);
					mapDeviceInfo.put(device.getAsString(), jao);
				}
			}
			System.out.println(mapDeviceInfo);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		deviceInfoFile = "./INFO/SERVER_COMMAND.JSON";
		try {
			String deviceInfo = readAll(deviceInfoFile);
			JsonObject jsonObj = (JsonObject) JsonParser.parseString(deviceInfo);
			JsonElement je = jsonObj.get("serverCommandInfo");
			JsonArray ja = je.getAsJsonArray();
			int len = ja.size();
			for (int i = 0; i < len; i++) {
				JsonElement jae = ja.get(i);
				JsonObject jao = jae.getAsJsonObject();
				String reqCmd = jao.get("command").getAsString();
				JsonElement forwardCmd = jao.get("forwardCommandInfo");
				JsonArray jaCmd = forwardCmd.getAsJsonArray();
				int lenCmd = jaCmd.size();
				if (lenCmd == 0) {
					continue;
				}
				HashMap<String, String[]> mapCommand = new HashMap<String, String[]>();
				for (int j = 0; j < lenCmd; j++) {
					JsonElement jaeCmd = jaCmd.get(j);
					JsonObject jaoCmd = jaeCmd.getAsJsonObject();
					String reqType = jaoCmd.get("type").getAsString();
					JsonArray reqForCmd = jaoCmd.get("forwardCommand").getAsJsonArray();
					int lenForCmd = reqForCmd.size();
					String[] arrCmd = new String[lenForCmd];
					for (int k=0; k<lenForCmd; k++) {
						arrCmd[k] = reqForCmd.get(k).getAsString();
					}
					mapCommand.put(reqType, arrCmd);
				}
				mapServerCommandInfo.put(reqCmd, mapCommand);
			}
			System.out.println(mapServerCommandInfo);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		EdgeNodeServer server = new EdgeNodeServer();
		try {
			server.start();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String[] getServerCommand(String cmd, String type) {
		HashMap<String, String[]> map = mapServerCommandInfo.get(cmd);
		
		return map.get(type);
	}

	public static String readAll(String filePath) throws IOException {

		StringBuilder stringBuilder;
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		try {
			stringBuilder = new StringBuilder();
			fileReader = new FileReader(filePath);
			bufferedReader = new BufferedReader(fileReader);
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuilder.append(line).append('\n');
			}

		} finally {
			if (bufferedReader != null)
				try {
					bufferedReader.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
			if (fileReader != null)
				try {
					fileReader.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
		}

		return stringBuilder.toString();
	}

	public static JsonObject readDeviceInfo(String key) {
		JsonObject ret = mapDeviceInfo.get(key);

		return ret;
	}
}
