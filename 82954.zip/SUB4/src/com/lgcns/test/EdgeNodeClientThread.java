package com.lgcns.test;

import org.eclipse.jetty.client.HttpClient;
import org.eclipse.jetty.client.api.ContentResponse;
import org.eclipse.jetty.client.api.Request;
import org.eclipse.jetty.client.util.StringContentProvider;
import org.eclipse.jetty.http.HttpHeader;
import org.eclipse.jetty.http.HttpMethod;

public class EdgeNodeClientThread extends Thread {

	String host;
	String port;
	String body;
	
	public EdgeNodeClientThread(String host, String port, String body) {
		this.host = host;
		this.port = port;
		this.body = body;
	}

	@Override
	public void run() {
		HttpClient httpClient = new HttpClient();
		try {
			httpClient.start();
			Request request = httpClient.newRequest("http://" + host + ":" + port + "/fromEdge")
					.method(HttpMethod.POST);
			request.header(HttpHeader.CONTENT_TYPE, "application/json");
			request.content(new StringContentProvider(body, "utf-8"));

			ContentResponse contentRes = request.send();

			String ret = contentRes.getContentAsString();
			System.out.println(ret);

			httpClient.stop();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
