package com.lgcns.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class EdgeNodeServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		StringBuilder stringBuilder = new StringBuilder();
		InputStream inputStream = req.getInputStream();
		if (inputStream != null) {
			BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
			String line = "";
			while ((line = br.readLine()) != null) {
				stringBuilder.append(line);
			}
		}

		String bodyJson = stringBuilder.toString();
		JsonObject jsonObj = (JsonObject) JsonParser.parseString(bodyJson);

		JsonElement jeTargetDevice = jsonObj.get("targetDevice");
		JsonArray ja = jeTargetDevice.getAsJsonArray();
		int len = ja.size();
		String[] arrRes = new String[len];
		for (int i = 0; i < len; i++) {
			JsonElement jae = ja.get(i);
			String targetDevice = jae.getAsString();
			JsonObject jo = RunManager.mapDeviceInfo.get(targetDevice);
			String host = jo.get("hostname").getAsString();
			String port = jo.get("port").getAsString();
			String type = jo.get("type").getAsString();
			int paraCount = jo.get("parallelProcessingCount").getAsInt();

			String reqCommand = jsonObj.get("command").getAsString();
			String param = jsonObj.get("param").getAsString();
//			String targetCommand = RunManager.mapServerCommandInfo.get(jeCommand.getAsString());
			String[] arrCommand = RunManager.getServerCommand(reqCommand, type);

			ArrayList threadList = new ArrayList();
			int lenCmd = arrCommand.length;
			for (int j = 0; j < lenCmd; j++) {
				String cmd = arrCommand[j];
				String targetbody = "{\"command\":\"" + cmd + "\", \"param\":\"" + param + "\"}";

//				if (paraCount == 1) {
					try {
						EdgeNodeClient edgeNodeClient = new EdgeNodeClient();
						String retJson = edgeNodeClient.send(host, port, targetbody);
						JsonObject jsonRes = (JsonObject) JsonParser.parseString(retJson);
						JsonElement jeRes = jsonRes.get("result");
						JsonArray jaRes = jeRes.getAsJsonArray();
						String resCode = jaRes.get(0).getAsString();
						if (j == lenCmd - 1) {
							arrRes[i] = resCode;
						} else {
							param = resCode;
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
//				} else {
//
//					try {
//						EdgeNodeClientThread edgeNodeClient = new EdgeNodeClientThread(host, port, targetbody);
//						edgeNodeClient.start();
//
//						threadList.add(edgeNodeClient);
//
//						if ((i + 1) % paraCount == 0) {
//
//						}
//						if (((i + 1) % this.reqThreadCnt == 0) || (i == (reqList.size() - 1))) {
//							super.checkThreadListAlive(threadList, 3000);
//							threadList.clear();
//						}
//						
//						edgeNodeClient.join();
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//				}
			}
		}

		JsonObject resJson = new JsonObject();
		JsonArray resArray = new JsonArray();
		for (int k = 0; k < arrRes.length; k++) {
			resArray.add(arrRes[k]);
		}

		resJson.add("result", resArray);
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String serverRes = gson.toJson(resJson);

		res.setStatus(200);
		res.getWriter().write(serverRes);
	}
}
