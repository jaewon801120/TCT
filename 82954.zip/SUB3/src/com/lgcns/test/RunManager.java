package com.lgcns.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class RunManager {

	public static HashMap<String, JsonObject> mapDeviceInfo = new HashMap<String, JsonObject>();
	public static HashMap<String, String> mapServerCommandInfo = new HashMap<String, String>();

	public static void main(String[] args) {

		String deviceInfoFile = "./INFO/DEVICE.JSON";
		try {
			String deviceInfo = readAll(deviceInfoFile);
			JsonObject jsonObj = (JsonObject) JsonParser.parseString(deviceInfo);
			JsonElement je = jsonObj.get("deviceInfo");
			JsonArray ja = je.getAsJsonArray();
			int len = ja.size();
			for (int i = 0; i < len; i++) {
				JsonElement jae = ja.get(i);
				JsonObject jao = jae.getAsJsonObject();
				JsonElement device = jao.get("device");
				mapDeviceInfo.put(device.getAsString(), jao);
			}
			System.out.println(mapDeviceInfo);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		deviceInfoFile = "./INFO/SERVER_COMMAND.JSON";
		try {
			String deviceInfo = readAll(deviceInfoFile);
			JsonObject jsonObj = (JsonObject) JsonParser.parseString(deviceInfo);
			JsonElement je = jsonObj.get("serverCommandInfo");
			JsonArray ja = je.getAsJsonArray();
			int len = ja.size();
			for (int i = 0; i < len; i++) {
				JsonElement jae = ja.get(i);
				JsonObject jao = jae.getAsJsonObject();
				JsonElement device = jao.get("command");
				JsonElement forwardCmd = jao.get("forwardCommand");
				mapServerCommandInfo.put(device.getAsString(), forwardCmd.getAsString());
			}
			System.out.println(mapServerCommandInfo);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		EdgeNodeServer server = new EdgeNodeServer();
		try {
			server.start();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String getDeviceInfo(String key) {
		String ret = "";

		return ret;
	}

	public static String readAll(String filePath) throws IOException {

		StringBuilder stringBuilder;
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		try {
			stringBuilder = new StringBuilder();
			fileReader = new FileReader(filePath);
			bufferedReader = new BufferedReader(fileReader);
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuilder.append(line).append('\n');
			}

		} finally {
			if (bufferedReader != null)
				try {
					bufferedReader.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
			if (fileReader != null)
				try {
					fileReader.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
		}

		return stringBuilder.toString();
	}
	
	public static JsonObject readDeviceInfo(String key) {
		JsonObject ret = mapDeviceInfo.get(key);
		
		return ret;
	}
}
