package com.lgcns.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class EdgeNodeServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		StringBuilder stringBuilder = new StringBuilder();
		InputStream inputStream = req.getInputStream();
		if (inputStream != null) {
			BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
			String line = "";
			while ((line = br.readLine()) != null) {
				stringBuilder.append(line);
			}
		}

		String bodyJson = stringBuilder.toString();
		JsonObject jsonObj = (JsonObject) JsonParser.parseString(bodyJson);
		JsonElement jeCommand = jsonObj.get("command");
		JsonElement jeParam = jsonObj.get("param");
		String targetCommand = RunManager.mapServerCommandInfo.get(jeCommand.getAsString());
		String targetParam = jeParam.getAsString();
		String targetbody = "{\"command\":\"" + targetCommand + "\", \"param\":\"" + targetParam + "\"}";

		JsonElement jeTargetDevice = jsonObj.get("targetDevice");
		JsonArray ja = jeTargetDevice.getAsJsonArray();
		int len = ja.size();
		String[] arrRes = new String[len];
		for (int i = 0; i < len; i++) {
			JsonElement jae = ja.get(i);
			String targetDevice = jae.getAsString();
			JsonObject jo = RunManager.mapDeviceInfo.get(targetDevice);
			JsonElement jeHost = jo.get("hostname");
			JsonElement jePort = jo.get("port");
			EdgeNodeClient edgeNodeClient = new EdgeNodeClient();
			try {
				String retJson = edgeNodeClient.send(jeHost.getAsString(), jePort.getAsString(), targetbody);
				JsonObject jsonRes = (JsonObject) JsonParser.parseString(retJson);
				JsonElement jeRes = jsonRes.get("result");
				JsonArray jaRes = jeRes.getAsJsonArray();
				JsonElement jaeRes = jaRes.get(0);
				String resDevice = jaeRes.getAsString();
				arrRes[i] = resDevice;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		JsonObject resJson = new JsonObject();
		JsonArray resArray = new JsonArray();
		for (int k = 0; k < arrRes.length; k++) {
			resArray.add(arrRes[k]);
		}

		resJson.add("result", resArray);
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String serverRes = gson.toJson(resJson);

		res.setStatus(200);
		res.getWriter().write(serverRes);
	}
}
