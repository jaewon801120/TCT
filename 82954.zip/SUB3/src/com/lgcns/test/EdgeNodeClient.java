package com.lgcns.test;

import org.eclipse.jetty.client.HttpClient;
import org.eclipse.jetty.client.api.ContentResponse;
import org.eclipse.jetty.client.api.Request;
import org.eclipse.jetty.client.util.StringContentProvider;
import org.eclipse.jetty.http.HttpHeader;
import org.eclipse.jetty.http.HttpMethod;

public class EdgeNodeClient {

	public String send(String host, String port, String body) throws Exception {
		HttpClient httpClient = new HttpClient();
		httpClient.start();

		Request request = httpClient.newRequest("http://" + host + ":" + port + "/fromEdge").method(HttpMethod.POST);
		request.header(HttpHeader.CONTENT_TYPE, "application/json");
		request.content(new StringContentProvider(body, "utf-8"));

		ContentResponse contentRes = request.send();

		String ret = contentRes.getContentAsString();
		System.out.println(ret);

		httpClient.stop();

		return ret;
	}
}