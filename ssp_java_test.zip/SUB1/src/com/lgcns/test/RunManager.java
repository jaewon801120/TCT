package com.lgcns.test;

import java.io.*;
import java.util.*;

public class RunManager {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int imgye = Integer.parseInt(sc.next());
		if (imgye < 0 || imgye > 100)
			return;

		System.out.println("�Ӱ谪 : " + imgye);

		File to = new File("INPUT/MONITORING.TXT");
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(to));

			String retData = "";
			String line = null;
			while ((line = br.readLine()) != null) {

				MonData monData = new MonData();
				String[] words = line.split("#");
				monData.index = Integer.parseInt(words[0]);
				for (int i = 1; i < words.length; i++) {
					String word = words[i];
					String[] sector = word.split(":");

					if (i == 1) {
						monData.resUse = Integer.parseInt(sector[1]);
						continue;
					}
					
					ProcData procData = new ProcData();
					procData.name = sector[0];
					procData.resUse = Integer.parseInt(sector[1]);
					
					monData.procList.add(procData);
				}
				
				if (monData.resUse > imgye) {
					monData.over = true;
				}
				
				retData += monData.toString() + "\r\n";
				System.out.println(monData);
				
			}
			
			fileWrite("OUTPUT/REPORT.TXT", retData);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void fileWrite(String filePath, String content) throws IOException {
		 
	    FileWriter     fileWriter     = null;
	    BufferedWriter bufferedWriter = null;
	    try {
	        fileWriter     = new FileWriter(filePath);
	        bufferedWriter = new BufferedWriter(fileWriter);
	        bufferedWriter.write(content);
	 
	    } finally {
	        if (bufferedWriter != null) try { bufferedWriter.close(); } catch (Exception ex) { /* Do Nothing */ }
	        if (fileWriter     != null) try { fileWriter    .close(); } catch (Exception ex) { /* Do Nothing */ }
	    }
	}

}

class MonData {

	int index;
	int resUse;
	List<ProcData> procList = new ArrayList<ProcData>();
	boolean over;
	
	@Override
	public String toString() {
		String data = String.format("%04d#SYS:%03d", index, resUse);
		for (ProcData procData : procList) {
			data += String.format("#%s:%03d", procData.name, procData.resUse);
		}
		if (this.over) {
			data += "#Y";
		}
		else {
			data += "#N";
		}
		
		return data;
	}

}

class ProcData {
	String name;
	int resUse;
}