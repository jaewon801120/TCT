package com.lgcns.test;

import java.io.*;
import java.nio.file.*;
import java.nio.file.WatchEvent.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class RunManager {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int imgye = Integer.parseInt(sc.next());
		if (imgye < 0 || imgye > 100)
			return;

		System.out.println("�Ӱ谪 : " + imgye);

		MonMan monMan = MonMan.getInstance();
		monMan.imgye = imgye;

		watch();

		System.out.println(monMan);

		System.out.println("���α׷� ����");
	}

	public static void watch() {
		try {
			String dir = "INPUT";
			WatchService service;

			service = FileSystems.getDefault().newWatchService();
			Path path = Paths.get(dir);
			path.register(service, StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.ENTRY_DELETE,
					StandardWatchEventKinds.ENTRY_MODIFY);
			while (true) {
				// WatchKey key = service.take();
				WatchKey key = service.poll(10000, TimeUnit.MILLISECONDS);
				if (key == null) {
					System.out.println("���� �˻� ����");
					break;
				}

				List<WatchEvent<?>> list = key.pollEvents(); // �̺�Ʈ�� ���� ������ ���
				for (WatchEvent<?> event : list) {
					Kind<?> kind = event.kind();
					Path pth = (Path) event.context();
					if (kind.equals(StandardWatchEventKinds.ENTRY_MODIFY)) {

						MonMan monMan = MonMan.getInstance();
						monMan.makeMonData();

					}
				}
				if (!key.reset())
					break; // Ű ����
			}
			service.close();

		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void fileWrite(String filePath, String content) throws IOException {

		FileWriter fileWriter = null;
		BufferedWriter bufferedWriter = null;
		try {
			fileWriter = new FileWriter(filePath);
			bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.write(content);

		} finally {
			if (bufferedWriter != null)
				try {
					bufferedWriter.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
			if (fileWriter != null)
				try {
					fileWriter.close();
				} catch (Exception ex) {
					/* Do Nothing */ }
		}
	}

}

class MonData {

	int index;
	int resUse;
	List<ProcData> procList = new ArrayList<ProcData>();
	boolean over;
	int avg;

	@Override
	public String toString() {
		String data = String.format("%04d#SYS:%03d", index + 1, resUse);
		for (ProcData procData : procList) {
			data += String.format("#%s:%03d", procData.name, procData.resUse);
		}
		if (this.over) {
			data += "#Y";
		} else {
			data += "#N";
		}
		data += String.format("#%03d", this.avg);

		return data;
	}

}

class ProcData {
	String name;
	int resUse;
}

class MonMan {

	static MonMan instance_ = null;
	int imgye;
	List<MonData> monList = new ArrayList<MonData>();
	int oneIndex = -1;
	int oneCount = 0;
	int preErrorF = 0;
	boolean errorF = false;
	int maxErrorF = 0;

	static synchronized public MonMan getInstance() {
		if (instance_ == null)
			instance_ = new MonMan();
		return instance_;
	}

	public void makeMonData() {

		File to = new File("INPUT/MONITORING.TXT");
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(to));

			String line = null;

			while ((line = br.readLine()) != null) {

				String[] words = line.split("#");
				int newIndex = Integer.parseInt(words[0]) - 1;
				if (newIndex < monList.size()) {
					continue;
				}

				MonData monData = new MonData();
				monData.index = newIndex;

				for (int i = 1; i < words.length; i++) {
					String word = words[i];
					String[] sector = word.split(":");

					if (i == 1) {
						monData.resUse = Integer.parseInt(sector[1]);
						continue;
					}

					ProcData procData = new ProcData();
					procData.name = sector[0];
					procData.resUse = Integer.parseInt(sector[1]);

					monData.procList.add(procData);
				}

				if (monData.resUse > imgye) {
					monData.over = true;
				}

				monList.add(monData);

				monData.avg = getAvg(monData.index);
				
				System.out.println(monData);
				
				if (monData.avg < imgye) {
					errorF = false;
					oneCount = 0;
					preErrorF = monData.avg;
					
					continue;
				}
				
				if (errorF) {
					maxErrorF = Math.max(monData.avg, maxErrorF);
					
				}

				int nDif = preErrorF - monData.avg;
				if (nDif > 0) {
					
				}
				if (oneIndex == -1) {
					oneIndex = monData.index;
				}

				oneCount++;

				if (oneCount > 5) {
					errorF = true;
				}
				
				preErrorF = monData.avg;
			}


		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public int getAvg(int index) {
		if (index > monList.size()) {
			return 0;
		}

		int avg = 0;

		MonData monData = null;
		if (index == 0) {
			monData = monList.get(0);
			return monData.resUse;
		}

		int sum = 0;
		int count = 0;
		for (int i = index; i >= 0; i--) {
			monData = monList.get(i);
			sum += monData.resUse;

			count++;

			if (count == 3) {
				break;
			}
		}

		avg = Math.floorDiv(sum, count);

		return avg;
	}

	@Override
	public String toString() {
		String data = "";
		for (MonData monData : monList) {
			data += monData.toString() + "\r\n";
		}

		return data;
	}
}
