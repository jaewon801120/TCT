package com.lgcns.test;

import java.io.*;
import java.util.*;

public class RunManager {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int imgye = Integer.parseInt(sc.next());
		if (imgye < 0 || imgye > 100)
			return;

		System.out.println("�Ӱ谪 : " + imgye);

		File to = new File("INPUT/MONITORING.TXT");
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(to));

			MonMan monMan = new MonMan();
			
			String retData = "";
			String line = null;
			
			while ((line = br.readLine()) != null) {

				MonData monData = new MonData();
				String[] words = line.split("#");
				monData.index = Integer.parseInt(words[0]);
				for (int i = 1; i < words.length; i++) {
					String word = words[i];
					String[] sector = word.split(":");

					if (i == 1) {
						monData.resUse = Integer.parseInt(sector[1]);
						continue;
					}
					
					ProcData procData = new ProcData();
					procData.name = sector[0];
					procData.resUse = Integer.parseInt(sector[1]);
					
					monData.procList.add(procData);
				}
				
				if (monData.resUse > imgye) {
					monData.over = true;
				}
				
				System.out.println(monData);
				
				monMan.monList.add(monData);
			}
			
			for (int i=0; i<monMan.monList.size(); i++) {
				MonData temp = monMan.monList.get(i);
				temp.avg = monMan.getAvg(i);
			}
			
			System.out.println(monMan);
			
			fileWrite("OUTPUT/REPORT.TXT", monMan.toString());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void fileWrite(String filePath, String content) throws IOException {
		 
	    FileWriter     fileWriter     = null;
	    BufferedWriter bufferedWriter = null;
	    try {
	        fileWriter     = new FileWriter(filePath);
	        bufferedWriter = new BufferedWriter(fileWriter);
	        bufferedWriter.write(content);
	 
	    } finally {
	        if (bufferedWriter != null) try { bufferedWriter.close(); } catch (Exception ex) { /* Do Nothing */ }
	        if (fileWriter     != null) try { fileWriter    .close(); } catch (Exception ex) { /* Do Nothing */ }
	    }
	}

}

class MonData {

	int index;
	int resUse;
	List<ProcData> procList = new ArrayList<ProcData>();
	boolean over;
	int avg;
	
	@Override
	public String toString() {
		String data = String.format("%04d#SYS:%03d", index, resUse);
		for (ProcData procData : procList) {
			data += String.format("#%s:%03d", procData.name, procData.resUse);
		}
		if (this.over) {
			data += "#Y";
		}
		else {
			data += "#N";
		}
		data += String.format("#%03d", this.avg);
		
		return data;
	}

}

class ProcData {
	String name;
	int resUse;
}

class MonMan {
	List<MonData> monList = new ArrayList<MonData>();
	
	public int getAvg(int index) {
		if (index >= monList.size()) {
			return 0;
		}
		
		int avg = 0;
		
		MonData monData = null;
		if (index == 0) {
			monData = monList.get(0);
			return monData.resUse;
		}
		
		int sum = 0;
		int count = 0;
		for (int i=index; i>=0; i--) {
			monData = monList.get(i);
			sum += monData.resUse;
			
			count++;
			
			if (count == 3) {
				break;
			}
		}
		
		avg = Math.floorDiv(sum, count);
		
		return avg;
	}

	@Override
	public String toString() {
		String data = "";
		for (MonData monData : monList) {
			data += monData.toString() + "\r\n";
		}
		
		return data;
	}
}
