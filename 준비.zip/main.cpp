// SUB1.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#include <string>
#include <istream>
#include <fstream>
#include <iostream>
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <vector>

#pragma comment (lib, "Ws2_32.lib")

using namespace std;

#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT "9876"

template< typename... Args >
std::string string_sprintf(const char* format, Args... args);
string runzip(string lineData);
string findFirstFile(string input);
string FileList(string filePath, string fileName);
char* ConvertWCtoC(wchar_t* str);
wchar_t* ConvertCtoWC(char* str);
char encrypt(char ch);
bool isNum(char* ch);
void copyfile(const char* InputFilename, const char* OutputFilename);
char* ConvertUnicodeToMultybyte(wchar_t* strUnicode);
char* ConvertUnicodeToUTF8(wchar_t* strUnicode);
wchar_t* ConvertUTF8ToUnicode(char* pUTF8);

int main()
{
    WSADATA wsaData;
    int iResult;

    SOCKET ListenSocket = INVALID_SOCKET;
    SOCKET ClientSocket = INVALID_SOCKET;

    struct addrinfo* result = NULL;
    struct addrinfo hints;

    int iSendResult;
    char recvbuf[DEFAULT_BUFLEN];
    char sendbuf[DEFAULT_BUFLEN];
    int recvbuflen = DEFAULT_BUFLEN;

    // Initialize Winsock
    iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != 0) {
        printf("WSAStartup failed with error: %d\n", iResult);
        return 1;
    }

    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    hints.ai_flags = AI_PASSIVE;

    // Resolve the server address and port
    iResult = getaddrinfo(NULL, DEFAULT_PORT, &hints, &result);
    if (iResult != 0) {
        printf("getaddrinfo failed with error: %d\n", iResult);
        WSACleanup();
        return 1;
    }

    // Create a SOCKET for connecting to server
    ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (ListenSocket == INVALID_SOCKET) {
        printf("socket failed with error: %ld\n", WSAGetLastError());
        freeaddrinfo(result);
        WSACleanup();
        return 1;
    }

    // Setup the TCP listening socket
    iResult = bind(ListenSocket, result->ai_addr, (int)result->ai_addrlen);
    if (iResult == SOCKET_ERROR) {
        printf("bind failed with error: %d\n", WSAGetLastError());
        freeaddrinfo(result);
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    freeaddrinfo(result);

    iResult = listen(ListenSocket, SOMAXCONN);
    if (iResult == SOCKET_ERROR) {
        printf("listen failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    // Accept a client socket
    ClientSocket = accept(ListenSocket, NULL, NULL);
    if (ClientSocket == INVALID_SOCKET) {
        printf("accept failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    // No longer need server socket
    closesocket(ListenSocket);

    iResult = recv(ClientSocket, recvbuf, recvbuflen, 0);
    if (iResult <= 0)
    {
        return 1;
    }

    recvbuf[iResult] = '\0';

    string fileData = "";
    string filePath = ".\\BIGFILE\\*.*";
    string fileName = recvbuf;

    string fileNamePath = FileList(filePath, fileName);

    // read File
    ifstream openFile(fileNamePath.data());
    if (openFile.is_open() == false)
    {
        return 1;
    }

    std::vector<std::string> data;
    string line;
    string preData = "";
    int i = 0;
    int nCount = 0;
    string zipData = "";
    while (getline(openFile, line))
    {
        if (preData != line && i != 0) {
            if (nCount == 1) {
                zipData = preData;
            }
            else {
                zipData = string_sprintf("%d#%s", nCount, preData.c_str());
            }

            //fileData += runzip(zipData) + '\n';
            data.push_back(runzip(zipData));
            nCount = 0;
        }

        nCount++;
        preData = line;
        i++;

        if (openFile.eof() == true)
        {
            if (nCount == 1) {
                zipData = line;
            }
            else {
                zipData = string_sprintf("%d#%s", nCount, preData.c_str());
            }

            //fileData += runzip(zipData) + '\n';
            data.push_back(runzip(zipData));
        }
    }

    int nData = (int)data.size();
    for (int j = 0; j < nData; j++)
    {
        cout << data.at(j) << endl;
    }

    string sendData = data.at(0);
    strcpy(sendbuf, sendData.c_str());
    int nSend = strlen(sendbuf);

    // Echo the buffer back to the sender
    iSendResult = send(ClientSocket, sendbuf, nSend, 0);
    if (iSendResult == SOCKET_ERROR) {
        printf("send failed with error: %d\n", WSAGetLastError());
        closesocket(ClientSocket);
        WSACleanup();
        return 1;
    }

    int nIndex = 1;
    // Receive until the peer shuts down the connection
    do {

        iResult = recv(ClientSocket, recvbuf, recvbuflen, 0);
        if (iResult > 0)
        {
            recvbuf[iResult] = '\0';

            if (strcmp(recvbuf, "ACK") == 0)
            {
            }
            else if (strcmp(recvbuf, "ERR") == 0)
            {
                nIndex--;
            }
            else if (isNum(recvbuf) == true)
            {
                nIndex = atoi(recvbuf);
                if (nData <= nIndex)
                    break;
            }

            string sendData = data.at(nIndex);
            ZeroMemory(sendbuf, DEFAULT_BUFLEN);
            strcpy(sendbuf, sendData.c_str());
            nSend = strlen(sendbuf);

            // Echo the buffer back to the sender
            iSendResult = send(ClientSocket, sendbuf, nSend, 0);
            if (iSendResult == SOCKET_ERROR) {
                printf("send failed with error: %d\n", WSAGetLastError());
                closesocket(ClientSocket);
                WSACleanup();
                return 1;
            }
            printf("Bytes sent: %d\n", iSendResult);

            nIndex++;

            if (nData <= nIndex)
                break;
        }
        else if (iResult == 0)
            printf("Connection closing...\n");
        else {
            printf("recv failed with error: %d\n", WSAGetLastError());
            closesocket(ClientSocket);
            WSACleanup();
            return 1;
        }

    } while (iResult > 0);

    openFile.close();

    // shutdown the connection since we're done
    iResult = shutdown(ClientSocket, SD_SEND);
    if (iResult == SOCKET_ERROR) {
        printf("shutdown failed with error: %d\n", WSAGetLastError());
        closesocket(ClientSocket);
        WSACleanup();
        return 1;
    }

    // cleanup
    closesocket(ClientSocket);
    WSACleanup();

    // write File
    //filePath = ".\\ABCDFILE.TXT";

    //ofstream writeFile(filePath);
    //if (writeFile.is_open()) {
    //    writeFile << fileData;
    //    writeFile.close();
    //}

    return 0;
}

template< typename... Args >
std::string string_sprintf(const char* format, Args... args) {
    int length = std::snprintf(nullptr, 0, format, args...);

    char* buf = new char[length + 1];
    std::snprintf(buf, length + 1, format, args...);

    std::string str(buf);
    delete[] buf;
    return str;
}

string runzip(string lineData)
{
    string zipData = "";
    char pre = '\0';
    char ch = '\0';
    int nCount = 0;
    int nSize = (int)lineData.length();
    for (int i = 0; i < nSize; i++)
    {
        ch = lineData.at(i);
        if (pre != ch && i != 0)
        {
            if (nCount < 3) {
                for (int j = 0; j < nCount; j++)
                    zipData += pre;
            }
            else {
                zipData += string_sprintf("%d%c", nCount, pre);
            }

            nCount = 0;
        }

        nCount++;
        pre = ch;
    }

    if (nCount == 1) {
        zipData += ch;
    }
    else {
        zipData += string_sprintf("%d%c", nCount, ch);
    }

    string encZipData = "";
    nCount = (int)zipData.length();
    for (int k = 0; k < nCount; k++)
    {
        char chData = zipData.at(k);
        char chEncData = chData;
        if (chData > 64 && chData < 91)
        {
            chEncData = encrypt(chData);
        }

        encZipData += chEncData;
    }

    return encZipData;
}

string findFirstFile(string input)
{
    WIN32_FIND_DATA ffd;
    HANDLE hFind;
    string path = "";

    hFind = FindFirstFile(TEXT(".\\BIGFILE\\*.*"), &ffd);
    do
    {
        if (ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        {
            _tprintf(TEXT("[%s]\n"), ffd.cFileName);
        }
        else
        {
            _tprintf(TEXT("%s\n"), ffd.cFileName);
            string file = string_sprintf("%s", *ffd.cFileName);
            if (file == input)
            {
                return file;
            }
        }
    } while (FindNextFile(hFind, &ffd) != 0);

    FindClose(hFind);

    return path;
}

string FileList(string filePath, string fileName)
{
    HANDLE hSrch;
    WIN32_FIND_DATA wfd;

    BOOL bResult = TRUE;
    wchar_t drive[_MAX_DRIVE] = { 0, };
    wchar_t dir[MAX_PATH] = { 0, };
    wchar_t szBuffer[MAX_PATH] = { 0, };

    wchar_t* winput = ConvertCtoWC((char*)filePath.c_str());
    GetFullPathName(winput, MAX_PATH, szBuffer, NULL);
    delete[] winput;

    hSrch = FindFirstFile(szBuffer, &wfd);
    if (hSrch == INVALID_HANDLE_VALUE) {
        return "";
    }
    _wsplitpath(szBuffer, drive, dir, NULL, NULL);
    while (bResult)
    {
        char* file = ConvertWCtoC(wfd.cFileName);
        if (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        {
            if (strcmp(file, ".") != 0 && strcmp(file, "..") != 0)
            {
                //sprintf(newpath, "%s%s%s\\*.*", drive, dir, wfd.cFileName);
                string subpath = string_sprintf("%s%s%s\\*.*", ConvertWCtoC(drive), ConvertWCtoC(dir), ConvertWCtoC(wfd.cFileName));
                string result = FileList(subpath, fileName);
                if (result != "")
                    return result;
            }
        }
        else
        {
            if (strcmp(file, fileName.c_str()) == 0)
            {
                string subpath = string_sprintf("%s%s%s", ConvertWCtoC(drive), ConvertWCtoC(dir), ConvertWCtoC(wfd.cFileName));
                return subpath;
            }
        }
        delete[] file;

        bResult = FindNextFile(hSrch, &wfd);
    }

    FindClose(hSrch);

    return "";
}

//wchar_t ���� char ���� ����ȯ �Լ�
char* ConvertWCtoC(wchar_t* str)
{
    //��ȯ�� char* ���� ����
    char* pStr;

    //�Է¹��� wchar_t ������ ���̸� ����
    int strSize = WideCharToMultiByte(CP_ACP, 0, str, -1, NULL, 0, NULL, NULL);
    //char* �޸� �Ҵ�
    pStr = new char[strSize];

    //�� ��ȯ 
    WideCharToMultiByte(CP_ACP, 0, str, -1, pStr, strSize, 0, 0);
    return pStr;
}

///////////////////////////////////////////////////////////////////////
//char ���� wchar_t ���� ����ȯ �Լ�
wchar_t* ConvertCtoWC(char* str)
{
    //wchar_t�� ���� ����
    wchar_t* pStr;
    //��Ƽ ����Ʈ ũ�� ��� ���� ��ȯ
    int strSize = MultiByteToWideChar(CP_ACP, 0, str, -1, NULL, NULL);
    //wchar_t �޸� �Ҵ�
    pStr = new WCHAR[strSize];
    //�� ��ȯ
    MultiByteToWideChar(CP_ACP, 0, str, strlen(str) + 1, pStr, strSize);
    return pStr;
}

char encrypt(char ch)
{
    int n = (int)ch;
    n -= 5;
    if (n < 65)
        n += 26;

    return (char)n;
}

bool isNum(char* ch)
{
    if (ch == nullptr)
        return false;

    int nCount = (int)strlen(ch);
    for (int i = 0; i < nCount; i++)
    {
        char ch1 = ch[i];
        if (ch1 < '0' || ch1 > '9')
            return false;
    }

    return true;
}

void copyfile(const char* InputFilename, const char* OutputFilename)
{
    const int BUF_LEN = 4096;
    char buffer[BUF_LEN];
    fstream fs_in, fs_out;
    fs_in.open(InputFilename, fstream::in | fstream::binary);
    fs_out.open(OutputFilename, fstream::out | fstream::binary);
    while (!fs_in.eof())
    {
        fs_in.read(buffer, BUF_LEN);
        fs_out.write(buffer, fs_in.gcount());
    }
    fs_in.close();
    fs_out.close();
}


char* ConvertUnicodeToMultybyte(wchar_t* strUnicode)
{
    int nLen = WideCharToMultiByte(CP_ACP, 0, strUnicode, -1, NULL, 0, NULL, NULL);

    char* pMultibyte = new char[nLen];
    memset(pMultibyte, 0x00, (nLen) * sizeof(char));

    WideCharToMultiByte(CP_ACP, 0, strUnicode, -1, pMultibyte, nLen, NULL, NULL);

    return pMultibyte;
}

char* ConvertUnicodeToUTF8(wchar_t* strUnicode)
{
    int nLen = WideCharToMultiByte(CP_UTF8, 0, strUnicode, -1, NULL, 0, NULL, NULL);

    char* pMultibyte = new char[nLen];
    memset(pMultibyte, 0x00, (nLen) * sizeof(char));

    WideCharToMultiByte(CP_UTF8, 0, strUnicode, -1, pMultibyte, nLen, NULL, NULL);

    return pMultibyte;
}

wchar_t* ConvertUTF8ToUnicode(char* pUTF8)
{
    int nLen = (int)strlen(pUTF8);

    int nDestLen = MultiByteToWideChar(CP_UTF8, 0, pUTF8, -1, NULL, NULL);

    WCHAR* pWideChar = new WCHAR[nDestLen];
    ZeroMemory(pWideChar, (nDestLen) * sizeof(WCHAR));

    MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)pUTF8, -1, pWideChar, nDestLen);

    return pWideChar;
}
